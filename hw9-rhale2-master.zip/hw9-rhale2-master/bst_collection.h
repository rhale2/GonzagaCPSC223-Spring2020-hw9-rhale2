
//----------------------------------------------------------------------
// Author: Rebekah Hale
// Course: CPSC 223, Spring 2020
// Assign: 9
// File:   bst_collection.h
// Desc:   binary search tree key-value pair collection functions
//----------------------------------------------------------------------



#ifndef BST_COLLECTION_H
#define BST_COLLECTION_H

#include <vector>
#include <algorithm>           
#include "collection.h"


template<typename K, typename V>
class BSTCollection : public Collection<K,V>
{
public:

  // create an empty tree
  BSTCollection();
  
  // bst copy constructor
  BSTCollection(const BSTCollection <K,V>& rhs);

  // bst assignment operator
  BSTCollection<K,V>& operator=(const BSTCollection <K ,V >& rhs);

  // delete the bst
  ~BSTCollection();
  
  // add a new key-value pair into the collection 
  void add(const K& a_key, const V& a_val);

  // remove a key-value pair from the collectiona
  void remove(const K& a_key);

  // find and return the value associated with the key
  bool find(const K& search_key, V& the_val) const;

  // find and return the values with keys >= to k1 and <= to k2 
  void find(const K& k1, const K& k2, std::vector<V>& vals) const;
  
  // return all of the keys in the collection 
  void keys(std::vector<K>& all_keys) const;

  // return all of the keys in ascending (sorted) order
  void sort(std::vector<K>& all_keys_sorted) const;

  // return the number of key-value pairs in the collection
  int size() const;

  // return the height of the tree
  int height() const;
  
private:

  // tree node structure
  struct Node {
    K key;
    V value;
    Node* left;
    Node* right;
  };

  // helper to empty entire tree
  void make_empty(Node* subtree_root);
  
  // helper to calc tree height (can use std::max)
  int height(Node* subtree_root) const;

  // helper to build sorted list of keys (used by keys and sort)
  void inorder(const Node* subtree_root, std::vector<K>& keys) const;

  // helper to recursively find range of keys
  void range_search(const Node* subtree_root, const K& k1, const K& k2,
                    std::vector<V>& vals) const;

  // recursively (deep) copy ancestors of src to dst
  void preorder_copy(const Node* subtree_root_src, Node* subtree_root_dst);
	
  // helper function to remove a node recursively
  Node* remove(const K& key, Node* subtree_root);
  
  // number of k-v pairs in the collection
  int collection_size; 

  // tree root
  Node* root;
   
};


template <typename K, typename V>
// create an empty tree
BSTCollection<K,V> :: BSTCollection() :
collection_size(0), root(nullptr) {     
}


template <typename K, typename V>
//bst copy constructor
BSTCollection<K,V> :: BSTCollection(const BSTCollection<K,V>& rhs) : 
collection_size(0), root(nullptr) {
  *this = rhs;
}


template <typename K, typename V>
// delete the bst
BSTCollection<K,V> :: ~BSTCollection() {
  make_empty(root);
}

template <typename K, typename V>
// bst assignment operator
BSTCollection<K,V>& BSTCollection<K,V> :: operator=(const BSTCollection <K,V>& rhs) {
  if (this == &rhs) {
    return *this;
  }
  make_empty(root);
  Node* ptr = new Node;
  preorder_copy(rhs.root, ptr);
  std::vector<K> keys; 
  V val;
  
  for (int i = 0; i < rhs.size(); i++) {
    rhs.find(keys.at(i), val);
    add(keys.at(i), val);
  }

  return *this;
}


template <typename K, typename V>
// helper to empty entire tree
void BSTCollection<K,V> :: make_empty(Node* subtree_root) {
  if (subtree_root != nullptr) {
    make_empty(subtree_root->left);
    make_empty(subtree_root->right);
    delete subtree_root;
  }
}

template <typename K, typename V>
// helper to build sorted list of keys (used by keys and sort)
void BSTCollection<K,V> :: inorder(const Node* subtree, std::vector<K>& ks) const {
  if (subtree == nullptr) {
    return;
  }
  inorder(subtree->left, ks);
  ks.push_back(subtree->key);
  inorder(subtree->right, ks);
}

template <typename K, typename V>
// recursively (deep) copy ancestors of src to dst
void BSTCollection<K,V> :: preorder_copy(const Node* subtree_root_src, Node* subtree_root_dst) {
  if (subtree_root_src == nullptr) {
    return;
  }
  Node* ptr = new Node;
  ptr->key = subtree_root_src->key;
  ptr->value = subtree_root_src->value;
  preorder_copy(ptr->left, subtree_root_dst);
  preorder_copy(ptr->right, subtree_root_dst);
}

template <typename K, typename V>
//helper to recursively find range of values
void BSTCollection<K,V> :: range_search(const Node* subtree_root, const K& k1, const K& k2, std::vector<V>& vals) const {
  if (subtree_root == nullptr) {
    return;
  }
  range_search(subtree_root->left, k1, k2, vals);

  if (k1 <= subtree_root->key && k2 >= subtree_root->key) {
    vals.push_back(subtree_root->value);
  }
  range_search(subtree_root->right, k1, k2, vals);
}

template <typename K, typename V>
// return the height of the tree rooted at subtree_root
int BSTCollection<K,V> :: height(Node* subtree_root) const {
  if (subtree_root == nullptr) {
    return 0;
  }
  int lhs = 1 + height(subtree_root->left);
  int rhs = 1 + height(subtree_root->right);

  if (lhs > rhs) {
    return lhs;
  }
  return rhs;
}

template <typename K, typename V>
// remove a node from the bst
typename BSTCollection<K,V> :: Node* BSTCollection<K,V> :: remove(const K& key, Node* subtree_root) {
  if (subtree_root && key < subtree_root->key) {
    subtree_root->left = remove(key, subtree_root->left);
  }
  else if (subtree_root && key > subtree_root->key) {
    subtree_root->right = remove(key, subtree_root->right);
  }
  else if (subtree_root && key == subtree_root->key) {
    if (subtree_root->left == nullptr && subtree_root->right == nullptr) {
      subtree_root = nullptr;
      collection_size = collection_size - 1;
    }
    else if (subtree_root->left != nullptr && subtree_root->right == nullptr) {
      K k = subtree_root->left->key;
      V v = subtree_root->left->value;
      Node* leftNode = subtree_root->left->left;
      remove(key, subtree_root->left);
      subtree_root->key = k;
      subtree_root->value = v;
      subtree_root->left = leftNode;
      collection_size = collection_size - 1;
      return subtree_root;
    }
    else if (subtree_root->left == nullptr && subtree_root->right != nullptr) {
      K k = subtree_root->right->key;
      V v = subtree_root->right->value;
      Node* rightNode = subtree_root->right->right;
      remove(key, subtree_root->right);
      subtree_root->key = k;
      subtree_root->value = v;
      subtree_root->right = rightNode;
      collection_size = collection_size - 1;
      return subtree_root;
    }
    else if (subtree_root->left != nullptr && subtree_root->right != nullptr) {
      Node* ptr = new Node;
      ptr = subtree_root;

      while (ptr->left != nullptr) {
        ptr = ptr->left;
      }
      K k = ptr->key;
      V v = ptr->value;
      remove(key, ptr);
      ptr = nullptr;
      subtree_root->key = k;
      subtree_root->value = v;
      collection_size--;
      return subtree_root;
    }
  }
  return subtree_root;
}

template <typename K, typename V>
// add new node into the tree
void BSTCollection<K,V> :: add(const K& a_key, const V& a_val) {
  Node* ptr = new Node;
  ptr->key = a_key;
  ptr->value = a_val;
  ptr->left = nullptr;
  ptr->right = nullptr;

  if (root == nullptr) {
    root = ptr;
    collection_size = collection_size + 1;
    return;
  }

  if (root->left == nullptr && root->right == nullptr) {
    if (a_key < root->key) {
      root->left = ptr;
    }
    else {
      root->right = ptr;
    }
    collection_size = collection_size + 1;
    return;
  }

  Node* rootN = root;
  Node* ances = nullptr;

  while (rootN != nullptr) {
    ances = rootN;
    if (a_key <= rootN->key) {
      rootN = rootN->left;
    }
    else {
      rootN = rootN->right;
    }
  }

  if (a_key <= ances->key) {
      ances->left = ptr;
  }
  else {
      ances->right = ptr;
  }
  collection_size = collection_size + 1;
}


template <typename K, typename V>
// remove a key-value pair from th collection
void BSTCollection<K,V> :: remove(const K& key) { 
  root = remove(key, root); 
}


template <typename K, typename V>
// find the key and return the value by referance
bool BSTCollection<K,V> :: find(const K& key, V& val) const {
  Node* ptr = root;
  while (ptr != nullptr) {
    if (ptr->key == key) {
      val = ptr->value;
      return true;
    }
    else if (key <= ptr->key) {
      ptr = ptr->left;
    }
    else if (key > ptr->key) {
      ptr = ptr->right;
    }
  }
  return false;
}


template <typename K, typename V>
// find the keys associated with the value
void BSTCollection<K,V> :: find(const K& k1, const K& k2, std::vector<V>& vals) const {
  range_search(root, k1, k2, vals);
}


template <typename K, typename V>
// return a vector of all the keys in the tree
void BSTCollection<K,V> :: keys(std::vector<K>& ks) const { 
  inorder(root, ks); 
}


template <typename K, typename V>
// return a vector of sorted keys
void BSTCollection<K,V> :: sort(std::vector<K>& ks) const {
  inorder(root, ks); 
}


template <typename K, typename V>
// return number of keys in the collection
int BSTCollection<K,V> :: size() const { 
  return collection_size; 
}


template <typename K, typename V>
// return the height of the Tree
int BSTCollection<K,V> :: height() const {
  return height(root); 
}

#endif
